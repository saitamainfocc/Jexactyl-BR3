<?php

namespace Jexactyl\Exceptions;

class JexactylException extends \Exception
{
}
